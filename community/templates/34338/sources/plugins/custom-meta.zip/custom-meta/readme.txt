=== Custom Meta ===
Contributors: TheLinx
Donate link: www.unreliablepollution.net/
Tags: widget, meta, custom
Requires at least: 2.2
Tested up to: 2.7
Stable tag: 1.0

This plugin adds a widget that is like the default Meta widget, but customizable. (You can specify what links to show).

== Description ==

This plugin adds a widget that is like the default Meta widget, but customizable. (You can specify what links to show).

== Installation ==

1. Upload `custom-meta.php` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Use the Custom Meta widget in your sidebars and click '[EDIT]' to choose what links to show.

== Frequently Asked Questions ==

= Where can I ask for help? =

[On my site.](http://www.unreliablepollution.net/p/stuff-we-made/tup-release-custom-meta-plugin-for-wordpress "Go there!")

== Screenshots ==

1. cmeta-screenshot1.png
2. cmeta-screenshot2.png
