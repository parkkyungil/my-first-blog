=== Social Networks Widget ===
Contributors: frankieroberto
Tags: widget, social networks, social networking, facebook, youtube, twitter, flickr, linkedin
Requires at least: 2.8
Tested up to: 2.8.4
Stable tag: 0.2

This plugin makes a widget available which allows you to add links to your social networking sites.

== Installation ==

Install this plugin in the usual way, by downloading and unzipping the folder into your plugins directory (/wp-content/plugins).

The plugin then needs to be activated before it can be used.



== Frequently Asked Questions ==

= Can you add the XXX site? =

E-mail me and I'll consider it.

== Changelog ==

= 0.1 =
* Initial upload

= 0.2 ==
* Widget title can now be linked to one of your pages.